module.exports = TABLES = {
  User: "users",
};
